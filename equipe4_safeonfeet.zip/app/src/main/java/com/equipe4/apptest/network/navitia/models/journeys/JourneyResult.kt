package com.equipe4.apptest.network.navitia.models.journeys

data class JourneyResult(
    val journeys:List<Journey>
)