package com.equipe4.apptest.network.app.users

data class UserLogin(
    val email:String,
    val password:String
)