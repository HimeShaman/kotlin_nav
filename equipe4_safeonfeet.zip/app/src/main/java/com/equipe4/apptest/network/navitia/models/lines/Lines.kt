package com.equipe4.apptest.network.navitia.models.lines

data class Lines (
    val code:String,
    val id:String,
    val name:String
)