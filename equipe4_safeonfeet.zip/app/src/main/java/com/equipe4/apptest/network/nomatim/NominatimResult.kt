package com.equipe4.apptest.network.nomatim

data class NominatimResult (
    val lat:Float,
    val lon:Float,
    val display_name:String
){
}